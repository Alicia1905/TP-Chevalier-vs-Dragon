'use strict'; // Mode strict du JavaScript

/*************************************************************************************************/
/* **************************************** DONNEES JEU ******************************************/
/*************************************************************************************************/

let difficulty = requestInteger('Choisissez le niveau de difficulté :\n1. Facile\n2. Normal\n3. Difficile', 1, 3);
let classe = requestInteger("Choisissez votre classe :\n1. Chevalier\n2. Voleur\n3. Mage", 1, 3);

let player = {
    name: ['Chevalier', 'Voleur', 'Mage'][classe - 1],  // Nom basé en fonction la classe choisie
    hp: 0, // Points de vie (hit points) initialisée à 0
    maxHp: 0,
    class: ['chevalier', 'voleur', 'mage'][classe - 1],
    normalImg: 'knight.png',
    woundedImg: 'knight-wounded.png',
    winImg: 'knight-winner.png'
};

let dragon = {
    name: 'Dragon',
    hp: 0,
    maxHp: 0,
    normalImg: 'dragon.png',
    woundedImg: 'dragon-wounded.png',
    winImg: 'dragon-winner.png'
};

/*************************************************************************************************/
/* *************************************** FONCTIONS JEU *****************************************/
/*************************************************************************************************/

function throwDices(n, faces) {
    let total = 0;
    for (let i = 0; i < n; i++) {
        total += Math.floor(Math.random() * faces) + 1;
    }
    return total;
}

function getImage(currentHP, maxHP, normalImg, woundedImg) {
    return currentHP <= maxHP * 0.3 ? woundedImg : normalImg;
}

function afficherJauge(currentHP, maxHP) {
    let pourcentage = Math.round((currentHP / maxHP) * 100);
    let barColor = pourcentage < 30 ? 'red' : 'green';
    return `<div style="margin-top: 8px; margin-left: 100px; width: 200px; border: 1px solid black;">
        <div style="height: 20px; width: ${pourcentage}%; background-color: ${barColor};"></div>
    </div>`;
}

function afficherCombatant(combatant) {
    return `
    <div style="display: inline-block; text-align: center; margin-right: 40px;">
        <img src="images/${getImage(combatant.hp, combatant.maxHp, combatant.normalImg, combatant.woundedImg)}" alt="${combatant.name}"><br>
        ${afficherJauge(combatant.hp, combatant.maxHp)}
    </div>`;
}

function initialiserHP(difficulty, player, dragon) {
    switch (difficulty) {
        case 1:
            player.hp = 100 + throwDices(10, 10);
            dragon.hp = 100 + throwDices(5, 10);
            break;
        case 2:
            player.hp = 100 + throwDices(10, 10);
            dragon.hp = 100 + throwDices(10, 10);
            break;
        case 3:
            player.hp = 100 + throwDices(7, 10);
            dragon.hp = 100 + throwDices(10, 10);
            break;
    }
    player.maxHp = player.hp;
    dragon.maxHp = dragon.hp;
}

/*************************************************************************************************/
/* ************************************** CODE PRINCIPAL *****************************************/
/*************************************************************************************************/

initialiserHP(difficulty, player, dragon);

document.write(`<h2>Début du combat</h2>`);
document.write(`<p>${player.name} : ${player.hp} PV</p>`);
document.write(`<p>${dragon.name} : ${dragon.hp} PV</p>`);

let tour = 1;

while (player.hp > 0 && dragon.hp > 0) {
    document.write(`<h3>Tour n°${tour}</h3>`);

    let playerInitiative = throwDices(10, 6);

    // Bonus pour le voleur : initiative majorée de 1D6%
    if (player.class === 'voleur') {
        let bonusVoleur = Math.round(playerInitiative * (throwDices(1, 6) / 100));
        playerInitiative += bonusVoleur;
    }

    let dragonInitiative = throwDices(10, 6);
    let damage = throwDices(3, 6);
    let attacker, defender;

    if (playerInitiative >= dragonInitiative) {
        // Le joueur attaque
        attacker = player;
        defender = dragon;

        // Bonus chevalier : réduction des dégâts du dragon
        if (player.class === 'chevalier') {
            let reduction = Math.round(damage * (throwDices(1, 10) / 100)); // 1D10% de réduction
            damage -= reduction;
        }

        if (difficulty === 1) {
            damage += Math.round(damage * (throwDices(2, 6) / 100));
        } else if (difficulty === 3) {
            damage -= Math.round(damage * (throwDices(1, 6) / 100));
        }

        defender.hp -= damage;
        if (defender.hp < 0) defender.hp = 0;

    } else {
        // Le dragon attaque
        attacker = dragon;
        defender = player;

        // Bonus mage : dégâts majorés de 1D10%
        if (player.class === 'mage') {
            let bonusMage = Math.round(damage * (throwDices(1, 10) / 100)); // 1D10% de bonus
            damage += bonusMage;
        }

        if (difficulty === 1) {
            damage -= Math.round(damage * (throwDices(2, 6) / 100));
        } else if (difficulty === 3) {
            damage += Math.round(damage * (throwDices(1, 6) / 100));
        }

        defender.hp -= damage;
        if (defender.hp < 0) defender.hp = 0;
    }

    document.write(`<p>${attacker.name} attaque et inflige ${damage} points de dégâts !</p>`);
    document.write(`<p>PV ${player.name} : ${player.hp}</p>`);
    document.write(`<p>PV ${dragon.name} : ${dragon.hp}</p>`);
    document.write(afficherCombatant(player));
    document.write(afficherCombatant(dragon));

    tour++;
}

document.write(`<h2>Fin du combat</h2>`);
if (player.hp > 0) {
    document.write(`<p>Victoire du ${player.name} !</p>`);
    document.write(`<img src="images/${player.winImg}" alt="${player.name} vainqueur">`);
} else {
    document.write(`<p>Victoire du ${dragon.name} !</p>`);
    document.write(`<img src="images/${dragon.winImg}" alt="${dragon.name} vainqueur">`);
}
